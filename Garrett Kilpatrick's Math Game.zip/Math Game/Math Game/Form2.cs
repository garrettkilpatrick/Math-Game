﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Math_Game
{
    public partial class Form2 : Form
    {
        public static int gintDifficulty;
        public static bool gblnCancel;
        public Form2()
        {
            InitializeComponent();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            frmMathGame.gstrAnswer = txtAnswer.Text;
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            lblMathQuestion.Text = frmMathGame.gintRandomNum1 + " + " + frmMathGame.gintRandomNum2;
            txtAnswer.Text = "";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            gblnCancel = true;
            this.Close();
        }
    }
}
