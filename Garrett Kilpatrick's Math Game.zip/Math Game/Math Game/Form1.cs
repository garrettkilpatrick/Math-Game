﻿//Garrett Kilpatrick
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Math_Game
{
    public partial class frmMathGame : Form
    {
        int gintMaxValue;
        public static string gstrAnswer;
        public static int gintRandomNum1, gintRandomNum2, gintAnswer, gintCorrectAnswerCount = 0;
        public static Form2 gfrmGameForm = new Form2();
        public frmMathGame()
        {
            InitializeComponent();
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            Random rndRandomGen1 = new Random();
            Random rndRandomGen2 = new Random();
            bool blnCorrect = false;
            gintMaxValue = Form2.gintDifficulty + 1;
            gintCorrectAnswerCount = 0;
            Form2.gblnCancel = false;
            do
            {
                gintRandomNum1 = rndRandomGen1.Next(1, gintMaxValue);
                gintRandomNum2 = rndRandomGen1.Next(1, gintMaxValue);
                if (!Form2.gblnCancel)
                {
                    gfrmGameForm.ShowDialog();
                    if (!Form2.gblnCancel)
                    {
                        if (int.TryParse(gstrAnswer, out gintAnswer) == false)
                        {

                        }
                        else
                        {
                            blnCorrect = gintAnswer == (gintRandomNum1 + gintRandomNum2);
                            if (blnCorrect)
                            {
                                if (blnCorrect && gintCorrectAnswerCount == 2)
                                {
                                    MessageBox.Show("You Win!");
                                }
                                gintCorrectAnswerCount = gintCorrectAnswerCount + 1;
                            }
                            else
                            {
                                gintCorrectAnswerCount = 0;
                            }
                        }
                    }
                }
            } while (gintCorrectAnswerCount != 3 && !Form2.gblnCancel);

        }

        private void radEasy_CheckedChanged(object sender, EventArgs e)
        {
            btnPlay.Enabled= true;
            gintMaxValue = 11;
            Form2.gintDifficulty = 10;
            lblStatus.Text = "Add Numbers Between 1 and 10";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRules_Click(object sender, EventArgs e)
        {
            radEasy.Checked = false;
            radMedium.Checked = false;
            radHard.Checked = false;
            lblStatus.Text = "Get 3 questions correct in a row to win.";
        }

        private void radMedium_CheckedChanged(object sender, EventArgs e)
        {
            btnPlay.Enabled = true;
            gintMaxValue = 101;
            Form2.gintDifficulty = 100;
            lblStatus.Text = "Add Numbers Between 1 and 100";
        }

        private void radHard_CheckedChanged(object sender, EventArgs e)
        {
            btnPlay.Enabled = true;
            gintMaxValue = 1001;
            Form2.gintDifficulty = 1000;
            lblStatus.Text = "Add Numbers Between 1 and 1000";
        }

        private void frmMathGame_Load(object sender, EventArgs e)
        {
            btnPlay.Enabled = false;
            radEasy.Checked = false;
            radMedium.Checked = false;
            radHard.Checked = false;
            lblStatus.Text = "Welcome! Select a difficulty to play.";
        }
    }
}
